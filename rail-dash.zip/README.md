# Rail Dash

Subway Surfers jaisa endless runner — pure HTML5 Canvas, koi library ya build step nahi.

## Run
`index.html` ko browser me open karo, ya GitHub Pages on kar do (Settings → Pages → main branch / root).

## Controls
- Mobile: swipe left / right / up (jump) / down (roll)
- Keyboard: ← → ↑ ↓ ya A D W S

## Files
- `index.html` — page + menu/game-over screens
- `style.css` — UI styling
- `game.js` — poora game logic
