(() => {
'use strict';
const cv = document.getElementById('game'), ctx = cv.getContext('2d');
const $ = id => document.getElementById(id);
let W, H, laneW, horizon, baseY;
const K = 0.07;                       // perspective strength
function resize() {
  const d = Math.min(devicePixelRatio || 1, 2);
  W = innerWidth; H = innerHeight;
  cv.width = W * d; cv.height = H * d;
  ctx.setTransform(d, 0, 0, d, 0, 0);
  laneW = Math.min(W * 0.28, H * 0.2);
  horizon = H * 0.3; baseY = H * 0.84;
}
addEventListener('resize', resize); resize();

// project lane-x, depth z, height h -> screen
const P = (x, z, h = 0) => {
  const s = 1 / (1 + z * K);
  return { x: W / 2 + x * laneW * s, y: horizon + (baseY - horizon) * s - h * laneW * s, s };
};

let state = 'menu', speed, dist, coins, score, nextSpawn, objs, t, best = 0, shake = 0;
try { best = +localStorage.getItem('raildash-best') || 0; } catch (e) {}
const pl = { lane: 0, x: 0, h: 0, vy: 0, roll: 0 };
const skyline = Array.from({ length: 40 }, (_, i) => ({ x: i / 40, w: 0.02 + Math.random() * 0.04, h: 0.03 + Math.random() * 0.12 }));

function reset() {
  speed = 16; dist = 0; coins = 0; score = 0; nextSpawn = 0; objs = []; t = 0;
  Object.assign(pl, { lane: 0, x: 0, h: 0, vy: 0, roll: 0 });
}
const rnd = (a, b) => a + Math.random() * (b - a);

function spawnRow() {
  const lanes = [-1, 0, 1].sort(() => Math.random() - 0.5);
  const n = Math.random() < 0.55 ? 1 : 2;
  const types = ['barrier', 'tall', 'overhead'];
  for (let i = 0; i < n; i++) objs.push({ type: types[(Math.random() * 3) | 0], lane: lanes[i], z: 80 });
  const free = lanes[2];
  if (Math.random() < 0.8) for (let i = 0; i < 5; i++) objs.push({ type: 'coin', lane: free, z: 80 + i * 3 });
}

function start() {
  reset(); state = 'play';
  $('menu').classList.add('hidden'); $('over').classList.add('hidden'); $('hud').classList.remove('hidden');
}
function crash() {
  state = 'over'; shake = 0.4;
  if (score > best) { best = score; try { localStorage.setItem('raildash-best', best); } catch (e) {} }
  $('finalScore').textContent = score; $('finalCoins').textContent = coins;
  $('bestOver').textContent = best; $('over').classList.remove('hidden');
}

// ---------- input ----------
const act = {
  left: () => pl.lane = Math.max(-1, pl.lane - 1),
  right: () => pl.lane = Math.min(1, pl.lane + 1),
  up: () => { if (pl.h <= 0.001) { pl.vy = 4.4; pl.roll = 0; } },
  down: () => { pl.roll = 0.6; if (pl.h > 0) pl.vy = -9; }
};
addEventListener('keydown', e => {
  const m = { ArrowLeft: 'left', a: 'left', ArrowRight: 'right', d: 'right', ArrowUp: 'up', w: 'up', ' ': 'up', ArrowDown: 'down', s: 'down' }[e.key];
  if (state === 'menu' && (e.key === 'Enter' || e.key === ' ')) return start();
  if (state === 'over' && e.key === 'Enter') return start();
  if (m && state === 'play') { act[m](); e.preventDefault(); }
});
let tx, ty;
addEventListener('touchstart', e => { tx = e.touches[0].clientX; ty = e.touches[0].clientY; }, { passive: true });
addEventListener('touchend', e => {
  if (state !== 'play' || tx == null) return;
  const dx = e.changedTouches[0].clientX - tx, dy = e.changedTouches[0].clientY - ty;
  if (Math.max(Math.abs(dx), Math.abs(dy)) < 24) return;
  if (Math.abs(dx) > Math.abs(dy)) dx > 0 ? act.right() : act.left(); else dy < 0 ? act.up() : act.down();
  tx = null;
}, { passive: true });
$('startBtn').onclick = start; $('retryBtn').onclick = start;
$('bestMenu').textContent = best;

// ---------- update ----------
function update(dt) {
  t += dt; shake = Math.max(0, shake - dt);
  if (state !== 'play') { if (state === 'menu') t += 0; return; }
  speed = Math.min(36, speed + 0.35 * dt);
  dist += speed * dt;
  score = Math.floor(dist / 4) + coins * 10;
  $('score').textContent = score; $('coins').textContent = '🪙 ' + coins;

  pl.x += (pl.lane - pl.x) * Math.min(1, dt * 14);
  pl.vy -= 12 * dt; pl.h += pl.vy * dt;
  if (pl.h < 0) { pl.h = 0; pl.vy = 0; }
  pl.roll = Math.max(0, pl.roll - dt);

  nextSpawn -= speed * dt;
  if (nextSpawn <= 0) { spawnRow(); nextSpawn = rnd(16, 24) + speed * 0.15; }

  for (const o of objs) o.z -= speed * dt;
  for (const o of objs) {
    if (o.dead || Math.abs(o.z) > 0.7 || Math.abs(o.lane - pl.x) > 0.6) continue;
    if (o.type === 'coin') { o.dead = true; coins++; continue; }
    const rolling = pl.roll > 0 && pl.h < 0.05;
    const hit = o.type === 'barrier' ? pl.h < 0.38
              : o.type === 'tall' ? true
              : !rolling;
    if (hit) return crash();
  }
  objs = objs.filter(o => !o.dead && o.z > -4);
}

// ---------- draw ----------
function quad(a, b, c, d, col) {
  ctx.fillStyle = col; ctx.beginPath();
  ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.lineTo(c.x, c.y); ctx.lineTo(d.x, d.y); ctx.closePath(); ctx.fill();
}
// box on lane: width w (lane units), length l (depth), height h, bottom at hb
function box(lane, z, w, l, h, hb, top, front, side) {
  const x0 = lane - w / 2, x1 = lane + w / 2, zf = z, zb = z + l;
  const f = [P(x0, zf, hb), P(x1, zf, hb), P(x1, zf, hb + h), P(x0, zf, hb + h)];
  const bk = [P(x0, zb, hb + h), P(x1, zb, hb + h)];
  quad(f[3], f[2], bk[1], bk[0], top);
  if (lane + 0 < pl.x - 0.01 || lane > pl.x + 0.01) {
    const sx = lane < pl.x ? 1 : 0;
    const a = sx ? P(x1, zf, hb) : P(x0, zf, hb), b = sx ? P(x1, zf, hb + h) : P(x0, zf, hb + h);
    const c = sx ? P(x1, zb, hb + h) : P(x0, zb, hb + h), d = sx ? P(x1, zb, hb) : P(x0, zb, hb);
    quad(a, b, c, d, side);
  }
  quad(f[0], f[1], f[2], f[3], front);
}

function drawBackground() {
  const g = ctx.createLinearGradient(0, 0, 0, horizon + 20);
  g.addColorStop(0, '#2a2f78'); g.addColorStop(0.7, '#ff7a59'); g.addColorStop(1, '#ffc15e');
  ctx.fillStyle = g; ctx.fillRect(0, 0, W, horizon + 20);
  ctx.fillStyle = '#ffe9a8'; ctx.beginPath(); ctx.arc(W * 0.75, horizon * 0.62, laneW * 0.35, 0, 7); ctx.fill();
  ctx.fillStyle = '#3a2f6b';
  const off = (dist * 0.002) % 1;
  for (const b of skyline) {
    const x = ((b.x - off + 1) % 1) * W;
    ctx.fillRect(x, horizon - b.h * H, b.w * W, b.h * H + 2);
  }
  ctx.fillStyle = '#243a3a'; ctx.fillRect(0, horizon, W, H - horizon);   // side ground
}

function drawRoad() {
  const L = P(-1.5, 0, 0), R = P(1.5, 0, 0);
  const far = { y: horizon };
  // far point sets width
  const fl = P(-1.5, 400), fr = P(1.5, 400);
  quad({ x: fl.x, y: fl.y }, { x: fr.x, y: fr.y }, { x: P(1.5, -3).x, y: P(1.5, -3).y }, { x: P(-1.5, -3).x, y: P(-1.5, -3).y }, '#4a4a63');
  // sleepers
  const sp = 4, o = dist % sp;
  for (let z = -o; z < 90; z += sp) {
    const a = P(-1.5, z), b = P(1.5, z), c = P(1.5, z + 1.2), d = P(-1.5, z + 1.2);
    quad(a, b, c, d, '#3b3b55');
  }
  // rails
  for (const lx of [-1, 0, 1]) {
    for (const dx of [-0.43, -0.37, 0.37, 0.43]) {
      ctx.strokeStyle = Math.abs(dx) < 0.4 ? '#c9ccd8' : '#8d90a6';
      ctx.lineWidth = Math.max(1, laneW * 0.02);
      const a = P(lx + dx, 120), b = P(lx + dx, -3);
      ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke();
    }
  }
}

function drawObj(o) {
  const z = o.z;
  if (z > 110) return;
  if (o.type === 'coin') {
    const p = P(o.lane, z, 0.45), r = laneW * 0.13 * p.s, sq = Math.abs(Math.cos(t * 6 + o.z));
    ctx.fillStyle = '#ffd23f'; ctx.strokeStyle = '#c98a00'; ctx.lineWidth = Math.max(1, r * 0.2);
    ctx.beginPath(); ctx.ellipse(p.x, p.y, Math.max(1, r * sq), r, 0, 0, 7); ctx.fill(); ctx.stroke();
  } else if (o.type === 'barrier') {
    box(o.lane, z, 0.8, 0.5, 0.32, 0, '#ffe066', '#ff5a36', '#c8401f');
    const a = P(o.lane - 0.4, z, 0.16), b = P(o.lane + 0.4, z, 0.16);
    ctx.strokeStyle = '#fff'; ctx.lineWidth = Math.max(1, laneW * 0.05 * a.s);
    ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke();
  } else if (o.type === 'tall') {
    box(o.lane, z, 0.82, 6, 1.3, 0.1, '#7c8bb0', '#2f9e8f', '#237a6f');
    const w1 = P(o.lane - 0.28, z, 0.95), w2 = P(o.lane + 0.28, z, 0.95), s = w1.s;
    ctx.fillStyle = '#ffe9a8';
    ctx.fillRect(w1.x, w1.y, w2.x - w1.x, laneW * 0.3 * s);
    const l1 = P(o.lane - 0.28, z, 0.3), l2 = P(o.lane + 0.28, z, 0.3);
    ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.arc(l1.x, l1.y, laneW * 0.06 * s, 0, 7); ctx.arc(l2.x, l2.y, laneW * 0.06 * s, 0, 7); ctx.fill();
  } else {   // overhead bar: roll under
    for (const dx of [-0.42, 0.42]) box(o.lane + dx, z, 0.1, 0.1, 0.95, 0, '#999', '#bbb', '#888');
    box(o.lane, z, 0.95, 0.3, 0.4, 0.58, '#ffe066', '#ffb300', '#c98a00');
  }
}

function drawPlayer() {
  const bob = state === 'play' ? Math.sin(t * 16) : 0;
  const p = P(pl.x, 0, pl.h), rolling = pl.roll > 0 && pl.h < 0.05, u = laneW;
  const gs = P(pl.x, 0, 0);
  ctx.fillStyle = 'rgba(0,0,0,.35)'; ctx.beginPath();
  ctx.ellipse(gs.x, gs.y, u * 0.25 / (1 + pl.h), u * 0.07, 0, 0, 7); ctx.fill();
  ctx.save(); ctx.translate(p.x, p.y);
  if (rolling) {
    ctx.fillStyle = '#ff5a36'; ctx.beginPath(); ctx.ellipse(0, -u * 0.2, u * 0.26, u * 0.2, 0, 0, 7); ctx.fill();
    ctx.fillStyle = '#ffd1a6'; ctx.beginPath(); ctx.arc(u * 0.12, -u * 0.28, u * 0.1, 0, 7); ctx.fill();
  } else {
    const air = pl.h > 0.01;
    ctx.strokeStyle = '#243b8a'; ctx.lineWidth = u * 0.09; ctx.lineCap = 'round';
    const sw = air ? 0.1 : bob * 0.14;
    ctx.beginPath(); ctx.moveTo(-u * 0.07, -u * 0.38); ctx.lineTo(-u * 0.07 - sw * u, -u * 0.02);
    ctx.moveTo(u * 0.07, -u * 0.38); ctx.lineTo(u * 0.07 + sw * u, -u * 0.02); ctx.stroke();
    ctx.fillStyle = '#ff5a36'; ctx.beginPath(); ctx.roundRect(-u * 0.15, -u * 0.8, u * 0.3, u * 0.45, u * 0.08); ctx.fill();
    ctx.fillStyle = '#ffd1a6'; ctx.beginPath(); ctx.arc(0, -u * 0.9, u * 0.12, 0, 7); ctx.fill();
    ctx.fillStyle = '#ffd23f'; ctx.beginPath(); ctx.arc(0, -u * 0.94, u * 0.125, Math.PI, 0); ctx.fill();
  }
  ctx.restore();
}

function draw() {
  ctx.save();
  if (shake > 0) ctx.translate(rnd(-6, 6), rnd(-6, 6));
  drawBackground(); drawRoad();
  const list = objs.slice().sort((a, b) => b.z - a.z);
  let playerDone = false;
  for (const o of list) {
    if (!playerDone && o.z < 0) { drawPlayer(); playerDone = true; }
    drawObj(o);
  }
  if (!playerDone) drawPlayer();
  ctx.restore();
}

let last = performance.now();
reset();
(function loop(now) {
  const dt = Math.min(0.05, (now - last) / 1000); last = now;
  update(dt);
  if (state === 'menu') { dist += 6 * dt; t += dt; }
  draw();
  requestAnimationFrame(loop);
})(last);
})();
